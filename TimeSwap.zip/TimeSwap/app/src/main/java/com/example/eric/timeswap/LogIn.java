package com.example.eric.timeswap;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.eric.timeswap.Model.User;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.rengwuxian.materialedittext.MaterialEditText;

public class LogIn extends AppCompatActivity {
    EditText editName,editPass;
    Button btn_log_in;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        editPass = (MaterialEditText)findViewById(R.id.editPass);
        editName = (MaterialEditText)findViewById(R.id.editName);

        btn_log_in = (Button)findViewById(R.id.btn_log_in);

        //Initialize firebase
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference user_table = database.getReference("User");

        btn_log_in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final ProgressDialog mDialog = new ProgressDialog(LogIn.this);
                mDialog.setMessage("");
                mDialog.show();


                user_table.addValueEventListener(new ValueEventListener() {

                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        //If user exists, check password
                        if(dataSnapshot.child(editName.getText().toString()).exists()){

                            //Get user info
                            mDialog.dismiss();
                            User user = dataSnapshot.child(editName.getText().toString()).getValue(User.class);
                            if(user.getPassword().equals(editPass.getText().toString())){
                                Toast.makeText(LogIn.this, "Login successful!", Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(LogIn.this, "Password incorrect!", Toast.LENGTH_SHORT).show();
                            }
                        }
                        //If user does not exist
                        else{
                            Toast.makeText(LogIn.this,"User does not exist", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
            }
        });
    }
}
