package com.example.eric.timeswap.Model;
/**
 * Created by Eric on 3/23/2018.
 */

public class User {
    private String Name;
    private String Password;
    private Integer Zip;

    public User(){
    }

    public User(String userName, String password, Integer zip) {
        Name = userName;
        Password = password;
        Zip = zip;
    }

    public String getName(){
        return Name;
    }

    public void setName(String userName){
        Name = userName;
    }

    public String getPassword(){
        return Password;
    }

    public void setPassword(String pass){
        Password = pass;
    }
}
